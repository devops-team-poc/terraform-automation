from googleapiclient import discovery
import google.auth
import os
 
credentials,project  = google.auth.default()
service = discovery.build('sqladmin', 'v1beta4',cache_discovery=False)
instance = os.getenv('DB_INSTANCE_NAME')
policy = 'NEVER'

def stop_psql(event):
   dbinstancebody = {
      "settings": {           
           "activationPolicy": policy
      }
   }
   request = service.instances().patch(
      project=project,
      instance=instance,
      body=dbinstancebody).execute()
   return f"Cloud Sql {instance} Stopped"
