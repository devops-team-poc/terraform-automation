from google.cloud import redis_v1
from google.cloud import secretmanager_v1
import os
import google.auth

credentials,project  = google.auth.default()
instance_name = os.getenv('RADIS_INSTANCE_NAME')
redis_host = os.getenv('RADIS_HOST')
def update_redis_host(request):
    resis_client = redis_v1.CloudRedisClient()
    location_id = 'us-central1'
    instance_id = instance_name
    location_path = f'projects/{project}/locations/{location_id}/instances/{instance_id}'
    response = resis_client.get_instance(name=location_path)
    secret_client = secretmanager_v1.SecretManagerServiceClient()
    parent = secret_client.secret_path(project, redis_host)
    payload = f'{response.host}'.encode('UTF-8')
    # response = client.add_secret_version(parent=parent, payload=payload)
    response = secret_client.add_secret_version(request={'parent': parent, 'payload': {'data': payload}})
    print("Redis host updated in secret manager")
    return "Redis host updated in secret manager"
