from google.cloud import redis_v1
import os
import google.auth

instance_name = os.getenv('RADIS_INSTANCE_NAME')
credentials,project  = google.auth.default()
def delete_redis(request):
    client = redis_v1.CloudRedisClient()
    location_id = 'us-central1'
    instance_id = instance_name
    location_path = f'projects/{project}/locations/{location_id}/instances/{instance_id}'
    response = client.delete_instance(name=location_path)
    print (f"{instance_id} deleted")
    return f"{instance_id} deleted"
