from google.cloud import redis_v1
import os
import google.auth

credentials,project  = google.auth.default()
instance_name = os.getenv('RADIS_INSTANCE_NAME')
def create_redis(request):
    client = redis_v1.CloudRedisClient()
    location = 'us-central1'
    location_path = f'projects/{project}/locations/{location}'
    instance_id = instance_name
    tier = redis_v1.Instance.Tier.BASIC
    memory_size_gb = 1
    instance = {'tier': tier, 'memory_size_gb': memory_size_gb}
    response = client.create_instance(parent=location_path, instance_id=instance_id, instance=instance)
    print(f"{instance_id} Created")
    return f"{instance_id} Created"
